package Person;

public class Person {
    public void setName(String bart) {
    }

    public void setAge(int i) {
    }

    public String getName() {
        return null;
    }


}
