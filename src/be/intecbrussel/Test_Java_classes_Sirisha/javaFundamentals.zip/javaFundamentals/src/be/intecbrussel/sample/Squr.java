package be.intecbrussel.sample;

public class Squr extends  Rect{
    public final String DESC = "SQUR";
    public static void main(String[] args) {
        Squr sq = new Squr();





        System.out.println(sq.DESC);

        Rect rec = new Squr();
        System.out.println(rec.DESC);
    }
}
