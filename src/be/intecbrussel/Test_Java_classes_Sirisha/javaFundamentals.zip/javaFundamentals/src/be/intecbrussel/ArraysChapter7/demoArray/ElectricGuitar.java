package be.intecbrussel.ArraysChapter7.demoArray;

public class ElectricGuitar {
    private String brand;
    private int numberOfPickUps;
    private boolean rockStarUsesIt;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getNumberOfPickUps() {
        return numberOfPickUps;
    }

    public void setNumberOfPickUps(int num) {
        this.numberOfPickUps = num;
    }

    public boolean isRockStarUsesIt() {
        return rockStarUsesIt;
    }

    public void setRockStarUsesIt(boolean yesOrNo) {
        this.rockStarUsesIt = yesOrNo;
    }
}
