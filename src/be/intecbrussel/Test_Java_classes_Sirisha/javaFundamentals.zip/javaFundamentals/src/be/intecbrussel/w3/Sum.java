package be.intecbrussel.w3;

public class Sum {
    public static void main(StringEx[] args) {
        int number1 = 74;
        int number2 = 36;
        int result = number1 + number2;
        System.out.println(result);
    }
}
