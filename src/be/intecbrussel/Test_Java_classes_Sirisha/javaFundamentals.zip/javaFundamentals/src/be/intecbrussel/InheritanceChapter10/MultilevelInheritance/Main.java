package be.intecbrussel.InheritanceChapter10.MultilevelInheritance;

public class Main {
    public static void main(String[] args) {
        Three three = new Three();
        three.print_geek();
        three.print_for();
        three.print_geek();

    }
}
