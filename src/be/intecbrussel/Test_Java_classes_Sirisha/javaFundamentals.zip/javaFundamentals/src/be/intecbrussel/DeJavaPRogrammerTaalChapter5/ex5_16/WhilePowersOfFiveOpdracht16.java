package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_16;

public class WhilePowersOfFiveOpdracht16 {
    public static void main(String[] args) {
        int number = 5;
        while (number<=10000){
            System.out.println(number);
            number*=5;
        }
    }
}
