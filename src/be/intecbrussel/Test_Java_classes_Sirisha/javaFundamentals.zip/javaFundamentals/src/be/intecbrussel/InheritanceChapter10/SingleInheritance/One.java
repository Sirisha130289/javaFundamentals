package be.intecbrussel.InheritanceChapter10.SingleInheritance;

public class One {
    public void print_geek(){
        System.out.println("geeks");
    }
}
