package be.intecbrussel.practiceExercises;

public class TreeElement {

public void whoAmI(){
    System.out.println("I am an apple");
}


}
