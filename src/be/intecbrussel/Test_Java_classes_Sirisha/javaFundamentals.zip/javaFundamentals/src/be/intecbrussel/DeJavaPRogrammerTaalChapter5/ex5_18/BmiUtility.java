package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_18;

public class BmiUtility {

}
