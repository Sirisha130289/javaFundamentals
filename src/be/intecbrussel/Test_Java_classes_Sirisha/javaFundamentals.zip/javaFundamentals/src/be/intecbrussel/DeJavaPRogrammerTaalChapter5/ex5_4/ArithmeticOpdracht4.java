package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_4;

public class ArithmeticOpdracht4 {

    public static void main(String[] args) {

        int number1 = 5;
        int number2 = 6;
        System.out.println("The sum of both numbers is " + (number1 + number2));
        System.out.println("The difference of both numbers is " + (number1 - number2));
        System.out.println("The product of both numbers is " + (number1 * number2));
        System.out.println("The remainder of both numbers is " + (number1 / number2));
        System.out.println(--number1);
        System.out.println(number1--);
        System.out.println(++number1);
        System.out.println(number1++);

        char c = '7';
        System.out.println(c);

    }
}
