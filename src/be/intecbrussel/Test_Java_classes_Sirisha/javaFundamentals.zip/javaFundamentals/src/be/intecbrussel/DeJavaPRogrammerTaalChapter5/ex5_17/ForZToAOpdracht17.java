package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_17;

public class ForZToAOpdracht17 {
    public static void main(String[] args) {
        char alphabet;
        for( alphabet ='z'; alphabet >= 'a'; alphabet--){
            System.out.println(alphabet);
        }
    }
}
