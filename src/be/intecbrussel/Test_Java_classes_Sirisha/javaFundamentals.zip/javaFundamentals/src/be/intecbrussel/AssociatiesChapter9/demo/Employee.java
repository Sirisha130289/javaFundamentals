package be.intecbrussel.AssociatiesChapter9.demo;

public class Employee {

        private String name;

        // employee name
        Employee(String name)
        {
            this.name = name;
        }

        public String getEmployeeName()
        {
            return this.name;
        }
    }

