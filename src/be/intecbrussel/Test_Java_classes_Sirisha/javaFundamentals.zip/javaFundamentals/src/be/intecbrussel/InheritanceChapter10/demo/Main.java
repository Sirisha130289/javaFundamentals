package be.intecbrussel.InheritanceChapter10.demo;

public class Main {

    //driver class
    public static void main(String[] args) {
        MountainBike mb = new MountainBike(4,85,4);

        System.out.println(mb.toString());
    }
}
