package be.intecbrussel.AssociatiesChapter9.demo;

public class Bank  {
    private String name;

        // bank name
        Bank(String name)
        {
            this.name = name;
        }

        public String getBankName()
        {
            return this.name;
        }
}