//package be.intecbrussel.ArraysChapter7.demoArray;
//
//public class Dog2 {
////    public static void main(String[] args) {
////        int size;
////        String name;
////        public static void bark(){
////            if (size > 60) {
////                System.out.println("Wooof! Wooof!");
////            } else if (size > 14) {
////                System.out.println("Ruff! ruff!");
////            } else {
////                System.out.println("Yip!yip!");
////            }
////        }
////    }
////}
