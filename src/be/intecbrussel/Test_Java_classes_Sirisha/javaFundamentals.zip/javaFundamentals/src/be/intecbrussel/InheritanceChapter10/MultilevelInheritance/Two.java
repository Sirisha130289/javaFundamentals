package be.intecbrussel.InheritanceChapter10.MultilevelInheritance;

public class Two extends One {
    public void print_for(){
        System.out.println("for");
    }
}
