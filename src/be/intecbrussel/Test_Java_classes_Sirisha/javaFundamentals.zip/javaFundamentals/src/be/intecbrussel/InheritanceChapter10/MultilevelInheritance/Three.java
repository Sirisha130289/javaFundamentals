package be.intecbrussel.InheritanceChapter10.MultilevelInheritance;

public class Three extends Two {
    public void print_geek(){
        System.out.println("Geeks");
    }
}
