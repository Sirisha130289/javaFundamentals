package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_17;

public class ForPowersOfElevenOpdracht17 {
    public static void main(String[] args) {
        for(int number=11; number<=100000;){
            System.out.println(number);
            number*=11;
        }
    }
}
