package be.intecbrussel.OOPChapter6.demo;

import Person.Person;

public class PersonApp {

    public static void main(String[] args) {

        Person person = new Person();
        Person person2 = new Person();

        person.setName("Bart");
        person.setAge(30);

       /* System.out.println(person.getName());
        System.out.println(person.getAge());

        */
    }
}
