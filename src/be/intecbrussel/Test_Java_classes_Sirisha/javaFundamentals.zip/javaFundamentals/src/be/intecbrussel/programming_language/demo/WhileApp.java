package be.intecbrussel.programming_language.demo;

public class WhileApp {

    public static void main(String[] args) {

        System.out.println("Counting to ten");
        int i =0;
        while (i<=10) {

            System.out.println(++i);


        }
    }
}
