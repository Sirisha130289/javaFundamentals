package be.intecbrussel.InheritanceChapter10.SingleInheritance;

public class Two extends One {
    public void print_for(){
        System.out.println("for");
    }
}
