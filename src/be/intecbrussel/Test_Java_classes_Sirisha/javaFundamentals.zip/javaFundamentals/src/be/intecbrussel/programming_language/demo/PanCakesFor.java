package be.intecbrussel.programming_language.demo;

public class PanCakesFor {
    public static void main(String[] args) {

        System.out.println("Mix");

        for (int count = 0; count<10; count++ ){
            System.out.println("Bake PanCake "+ count);
        }
    }
}
