package be.intecbrussel.programming_language.demo;

public class Factorial {

    public static void main(String[] args) {

        for (int i = 2; i <= 1024; i= i*2) {
            System.out.println(i);
        }
    }
}
