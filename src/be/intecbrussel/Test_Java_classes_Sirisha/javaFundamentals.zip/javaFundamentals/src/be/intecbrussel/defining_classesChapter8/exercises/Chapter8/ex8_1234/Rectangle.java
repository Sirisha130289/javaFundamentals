package be.intecbrussel.defining_classesChapter8.exercises.Chapter8.ex8_1234;

public class Rectangle {

    double height;
    double width;
    int x,y;
}
