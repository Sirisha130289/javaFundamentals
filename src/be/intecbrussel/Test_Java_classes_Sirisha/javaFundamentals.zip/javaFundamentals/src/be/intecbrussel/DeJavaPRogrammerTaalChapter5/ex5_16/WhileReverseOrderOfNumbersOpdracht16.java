package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_16;

public class WhileReverseOrderOfNumbersOpdracht16 {
    public static void main(String[] args) {
        int number =120;
        while (number>=100){
            System.out.println(number);
            number--;
        }
    }
}
