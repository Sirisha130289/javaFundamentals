package be.intecbrussel.programming_language.CodingBat;

public class DiffBwLargestAndSmallestValue {
    public static void main(String[] args) {
        int[] nums = {10, 3, 5, 6};
int minimum=0;
        for (int index = 0; index < nums.length; index++) {

            int min;
           // min = Math.min(nums([index]);
           // int max = Math.max(nums([index]);
         //   int difference = max - min;
        //    System.out.println(difference);
        }

    }
}

