package be.intecbrussel.Test_Java_classes_Sirisha;

public class Tank {

    private double fuelCapacity;

    public void setFuelCapacity(double fuelCapacity) {
        this.fuelCapacity = fuelCapacity;
    }

    public double getFuelCapacity() {
        return fuelCapacity;
    }
}
