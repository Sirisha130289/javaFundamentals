package be.intecbrussel.programming_language.demo;

public class Test {

    public static void main(String[] args) {
         int x=10;
         while (x>=0){
             System.out.println("x = "+ x);
             x= x+1;
             System.out.println("x = " + x);
             x= x-3;

         }
    }
}
