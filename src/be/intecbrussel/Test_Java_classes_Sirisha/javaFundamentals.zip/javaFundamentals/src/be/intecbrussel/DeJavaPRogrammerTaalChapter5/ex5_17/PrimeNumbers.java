package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_17;

public class PrimeNumbers {
    public static void main(String[] args) {
        int number;
        for(number =2; number<1000;number++);
        boolean isPrime = true;


    }
}