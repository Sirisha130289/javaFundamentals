package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_2;

public class FinalVariableOpdracht2 {

    public static void main(String[] args) {
        final double PI = 3.14;

        //PI = 3.15;

        System.out.println(PI);
    }



}
