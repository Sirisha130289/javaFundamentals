package be.intecbrussel.programming_language.demo;

public class SequenceExampleApp {

    public static void main(String[] args) {

        System.out.println("take flour");
        System.out.println("add milk");
        System.out.println("add eggs");
        System.out.println("mix");
        System.out.println("bake");

    }



    }