package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_18;
import java.util.Scanner;
public class KeyboardUtility {

    public static int readInt() {
        Scanner keyboard = new Scanner(System.in);
        int scannerNumber = keyboard.nextInt();
        return scannerNumber;

    }
}
