package be.intecbrussel.defining_classesChapter8.exercises.Chapter8.ex8_8;

public class RectApp {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle();
        System.out.println(rect.getHeight());
        System.out.println(rect.getWidth());
        System.out.println(rect.getX());
        System.out.println(rect.getY());
    }
}
