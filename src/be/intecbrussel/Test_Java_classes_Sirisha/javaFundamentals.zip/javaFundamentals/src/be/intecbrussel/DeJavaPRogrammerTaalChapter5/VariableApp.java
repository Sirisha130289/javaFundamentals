package be.intecbrussel.DeJavaPRogrammerTaalChapter5;

public class VariableApp {}



