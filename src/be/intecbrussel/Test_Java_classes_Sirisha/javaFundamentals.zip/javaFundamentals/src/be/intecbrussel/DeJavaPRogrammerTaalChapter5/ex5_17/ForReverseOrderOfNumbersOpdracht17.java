package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_17;

public class ForReverseOrderOfNumbersOpdracht17 {
    public static void main(String[] args) {
        for( int number =400; number>=360; number--) {
            System.out.println(number);
        }
    }
}
