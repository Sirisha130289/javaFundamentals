package be.intecbrussel.ArraysChapter7.demoArray;

public class Dog {
    String name;





    public  void bark () {
            System.out.println(this.name+" is barking");
        }
        public  void chaseCat () {
            System.out.println("Chase the cat");
        }
        public  void eat () {
            System.out.println("Eat meat");
        }


    }



