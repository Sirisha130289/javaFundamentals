package be.intecbrussel.AssociatiesChapter9.demoAggregation;

public class Student {

        String name;
        int id ;
        String dept;

        Student(String name, int id, String dept)
        {

            this.name = name;
            this.id = id;
            this.dept = dept;

        }
    }
