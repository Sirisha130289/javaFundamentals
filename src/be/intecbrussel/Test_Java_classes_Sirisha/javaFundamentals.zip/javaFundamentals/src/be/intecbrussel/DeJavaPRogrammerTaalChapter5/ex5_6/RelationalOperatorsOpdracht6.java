package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_6;

public class RelationalOperatorsOpdracht6 {
    public static void main(String[] args) {
        int number1 = 8;
        int number2 = -6;

        System.out.println("number1 < number2 :" + (number1 < number2));
        System.out.println("number1 <= number2 :" + (number1 <= number2));
        System.out.println("number1 > number2 :" + (number1 > number2));
        System.out.println("number1 >= number2 :" + (number1 >= number2));
        System.out.println("number1 == number2 :" + (number1 == number2));
        System.out.println("number1 != number2 :" + (number1 != number2));

    }
}
