package be.intecbrussel.InheritanceChapter10.SingleInheritance;

public class Main {
    public static void main(String[] args) {
        One one = new One();
        Two two = new Two();
        two.print_geek();
        two.print_for();
        two.print_geek();


    }
}
