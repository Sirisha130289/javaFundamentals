package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_16;

public class WhileMultiplesOfThree16 {
    public static void main(String[] args) {
        int number =3;
        while (number<=50){
            System.out.println(number);
            number += 3;
        }
    }
}
