package be.intecbrussel.Test_Java_classes_Sirisha;

public class RocketEngine {
    private double usage;

    public double getUsage() {
        return usage;
    }

    public void setUsage(double usage) {
        this.usage = usage;
    }
}
