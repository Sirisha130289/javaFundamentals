package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_16;

public class WhilePrintAlphabetsOpdracht16<z> {
    public static void main(String[] args) {
        char alphabet = 'A';
        while (alphabet<='Z') {
            System.out.println(alphabet);
            alphabet++;
        }
    }


}
