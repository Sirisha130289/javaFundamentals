package be.intecbrussel.InheritanceChapter10.demo.InheritanceExample;

public class ApacheAttackHelicopter extends Helicopter {

    public int weaponCapacity;
    public void fireWeapons(){
        System.out.println("Phew phew");
    }

}
