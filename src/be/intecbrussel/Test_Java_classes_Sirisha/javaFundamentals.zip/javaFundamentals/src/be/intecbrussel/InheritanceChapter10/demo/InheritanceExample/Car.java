package be.intecbrussel.InheritanceChapter10.demo.InheritanceExample;

public abstract class Car extends Vehicle {
}
