package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_18;

public class BmiApplication {

    public static void main(String[] args) {

        System.out.println("Enter your Length in (cms) : ");
        int height = KeyboardUtility.readInt();
        System.out.println("Enter your weight (kg): ");
        int weight = KeyboardUtility.readInt();
      //  double bmi = BmiUtility.calculateBmi(weight,height);
       // BmiUtility.printDiagnose(bmi);
    }
}
