package be.intecbrussel.programming_language.demo;

public class ForApp {
    public static void main(String[] args) {

        System.out.println("take a bowl");
        System.out.println("add flour");
        System.out.println("add milk");
        System.out.println("add eggs");
        System.out.println("add vanilla sugar");

        for (int iteration = 0; iteration <10; iteration ++) {
            System.out.println("Whisk the batter");
        }

        System.out.println("Pour the batter in the pan");
        System.out.println("Put the batter on the fire");
        System.out.println("Wait till the batter is dry on the top");
        System.out.println("Throw pank cake into the air like you dont care");
        System.out.println("Catch");
        System.out.println("Wait 34 sec");
        System.out.println("Serve the pancake");
    }



}
