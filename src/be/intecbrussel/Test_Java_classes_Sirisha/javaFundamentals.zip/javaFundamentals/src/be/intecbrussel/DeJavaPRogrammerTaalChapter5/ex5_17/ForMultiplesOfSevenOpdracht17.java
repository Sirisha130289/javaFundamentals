package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_17;

public class ForMultiplesOfSevenOpdracht17 {
    public static void main(String[] args) {
        for(int number=7; number<=200;){
            System.out.println(number);
            number+=7;
        }
    }
}
