package be.intecbrussel.w3;

public class Divide {
    public static void main(StringEx[] args) {
        int number1= 50;
        int number2 = 3;
        int result = number1/number2;
        System.out.println(result);
    }
}
