package be.intecbrussel.DeJavaPRogrammerTaalChapter5.ex5_17;

public class ForIfNosBetweenOpdracht17 {
    public static void main(String[] args) {
        int a ;

        for (a = -10; a <= 10; a++) {
            {
                if (a <= 0) {
                    System.out.println(a);
                } else {
                    System.out.println("+"+ a);
                }
            }
        }
    }
}


